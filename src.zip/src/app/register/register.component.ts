import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  user:any;

  constructor(private router:Router, private service:StudentService, private toastr: ToastrService) { }

  ngOnInit(): void {
    
  }

  
  register(registerForm:any):void{
    console.log('registerUser method called');
    this.service.registerStudent(registerForm).subscribe((result: any) => console.log(result));
    this.toastr.success("Registered Successfully");
    console.log(registerForm);
  }
  
  
  }
