import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { map } from 'rxjs/Operators';
import { analyzeAndValidateNgModules } from '@angular/compiler';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

   url = "http://localhost:4200"
  private isUserLogged:any;
  constructor(private httpClient:HttpClient) {
    this.isUserLogged = false;
   }
   login(model: any){
     return this.httpClient.post(this.url + 'login',model).pipe();
     map((response: any) =>
         {const user = response;
         if(user.result.succeeded){
              localStorage.setItem("token",user.token)
         }
     })
   }
   setUserLoggedIn(): void{
     this.isUserLogged=true;
   }
   setUserLoggedOut(): void{
     this.isUserLogged=false;
   }

    getUserLogged(): any{
      return this.isUserLogged;
    }

    registerStudent(student:any) {
      return this.httpClient.post('RESTAPI2018/webapi/myresource/registerStudent', student);
    }
    loginVerification(loginForm:any){
      console.log(loginForm.loginId);
      return this.httpClient.get('RESTAPI2018/webapi/myresource/loginVerification/'+ loginForm.loginId);
    }
    getCourseByName(course: any){
      console.log(course);
      return this.httpClient.get('RESTAPI2018/webapi/myresource/getCourseByName/'+ course);
    }
    confirmEmail(model: any){
      

    }

    resetPassword(f : any){

    }
    postFile(ImageForm: any,fileToUpload: File){
      const endpoint = 'RESTAPI2018/webapi/myresource/uploadImage';
      const formData: FormData = new FormData();
      formData.append('Image',fileToUpload, fileToUpload.name);
      formData.append('courseName', ImageForm.courseName);
      formData.append('description',ImageForm.description);
      formData.append('level',ImageForm.level);
      formData.append('price',ImageForm.price);
      
      return this.httpClient.post(endpoint, formData);
    }
}