
import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.css']
})
export class CourseDetailsComponent implements OnInit {

  course: any;
  constructor() { }

  ngOnInit(): void {
    this.course = this.course;    
  }

}