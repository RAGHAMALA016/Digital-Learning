import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user :any;
  constructor(private router:Router,private service:StudentService) { 
    this.user ={loginId:'',password:''};

  }

  ngOnInit(): void {
  }
loginUser():void{
  console.log('loginUser method called');
  console.log(this.user);

}
validateUser(loginForm:any){
    if(loginForm.loginId==='admin' && loginForm.password==='admin'){
      this.service.setUserLoggedIn(); 
      this.router.navigate(['home']);
    }
    else{
      this.service.loginVerification(loginForm).subscribe((result:any) =>{console.log(result);this.user=result;
      console.log(this.user);
      if(this.user){
          this.router.navigate(['courses']);
      }
      
      else{
        //this.toastr.error("Not Registered!") 
        this.router.navigate(['home']);
      }
    });
    }
  
  console.log(loginForm);

}

  
}


