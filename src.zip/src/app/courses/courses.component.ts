
import { CourseDetailsComponent } from './../course-details/course-details.component';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';


@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  courses: any;
  course:any;

  constructor(private router:Router, private service:StudentService) { }

  onSelect(course:any): void{
    
    console.log(course);
    this.router.navigate(['course-details']);
    this.service.getCourseByName(course).subscribe((result:any) =>{console.log(result);this.course=result});
    
    
  }
 
  ngOnInit(): void {
   this.courses = [
      {
          id: 1001, name: 'CProgramming', duration: 3, price: 1100.00, imagePath: 'assets/Images/101.jpg',
          level: 'Intermediate', description: 'This specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programs. Through four courses, you will learn to develop algorithms in a systematic way and read and write the C code to implement them. '
      },
      {
          id: 1002, name: 'python', duration: 3, price: 1200.00, imagePath: 'assets/Images/102.jpg',
          level: 'Beginner', description: 'This Specialization builds on the success of the Python for Everybody course and will introduce fundamental programming concepts including data structures, networked application program interfaces, and databases, using the Python programming language. In the Capstone Project, you’ll use the technologies learned throughout the Specialization to design and create your own applications for data retrieval, processing, and visualization.'
      },
      {
          id: 1003, name: 'Machine Learning', duration: 8, price: 1250.00, imagePath: 'assets/Images/103.jpg',
          level: 'Intermediate', description: 'This Specialization from leading researchers at the University of Washington introduces you to the exciting, high-demand field of Machine Learning. Through a series of practical case studies, you will gain applied experience in major areas of Machine Learning including Prediction, Classification, Clustering, and Information Retrieval. You will learn to analyze large and complex datasets, create systems that adapt and improve over time, and build intelligent applications that can make predictions from data.'
      },
      {
          id: 1004, name: 'Java Programming', duration: 4, price: 1200.00, imagePath: 'assets/Images/104.jpg',
          level: 'Advanced', description: 'Designed for beginners, this Specialization will teach you core programming concepts and equip you to write programs to solve complex problems. In addition, you will gain the foundational skills a software engineer needs to solve real-world problems, from designing algorithms to testing and debugging your programs '
      },
      {
          id: 1005, name: 'Introduction to MATLAB', duration: 6, price: 1500.00, imagePath: 'assets/Images/105.jpg',
          level: 'Beginner', description: 'This course teaches computer programming to those with little to no previous experience. It uses the programming system and language called MATLAB to do so because it is easy to learn, versatile and very useful for engineers and other professionals. MATLAB is a special-purpose language that is an excellent choice for writing moderate-size programs that solve problems involving the manipulation of numbers. The design of the language makes it possible to write a powerful program in a few lines. The problems may be relatively complex, while the MATLAB programs that solve them are relatively simple. As a result, MATLAB is being used in a wide variety of domains from the natural sciences, through all disciplines of engineering, to finance, and beyond, and it is heavily used in industry. Hence, a solid background in MATLAB is an indispensable skill in today’s job market. Students who successfully complete this course will become familiar with general concepts in computer science, gain an understanding of the general concepts of programming, and obtain a solid foundation in the use of MATLAB.'
      },
      {
          id: 1006, name: 'C++ Programming Language', duration: 3, price: 1000.00, imagePath: 'assets/Images/106.jpg',
          level: 'Beginner', description: 'This course is for experienced C programmers who want to program in C++. The examples and exercises require a basic understanding of algorithms and object-oriented software.'
      },
      {
          id: 1007, name: 'Arduino Basics', duration: 2, price: 800.00, imagePath: 'assets/Images/107.jpg',
          level: 'Beginner', description: 'Our course consists of a series of practical problems on making things that work independently: they make their own decisions, act, move, communicate with each other and people around, and control other devices. We will demonstrate how to assemble such devices and programme them using the Arduino platform as a basis. You will be able to create devices that read the data about the external world with a variety of sensors, receive and forward this data to a PC, the Internet and mobile devices, and control indexing and the movement. The creation of such devices will involve design, the study of their components, the assemblage of circuit boards, coding and diagnostics. Along with the creation of the devices themselves.'
      },
      {
          id: 1008, name: 'IOT', duration: 8, price: 1350.00, imagePath: 'assets/Images/108.jpg',
          level: 'Intermediate', description: 'This Specialization covers the development of Internet of Things (IoT) products and services—including devices for sensing, actuation, processing, and communication—to help you develop skills and experiences you can employ in designing novel systems. The Specialization has theory and lab sections. In the lab sections you will learn hands-on IoT concepts such as sensing, actuation and communication.'
      }
  ];
  }

}
