
package com.ts.dao;

import java.util.List;


import com.rest.dto.Student;
import com.ts.db.HibernateTemplate;

public class StudentDAO {

	
	
	public int register(Student student) {
		//java.util.Date utilDate = new java.sql.Date(student.getJoinDate().getTime()); 
		return HibernateTemplate.addObject(student);
	}
	
	public List<Student> getAllStudents() {
		List<Student> students=(List)HibernateTemplate.getObjectListByQuery("From Student");
		System.out.println("Inside All Students ..."+students);
		return students;	
	}
}
