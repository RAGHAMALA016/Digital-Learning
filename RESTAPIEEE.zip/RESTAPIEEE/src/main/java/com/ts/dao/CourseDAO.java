package com.ts.dao;

import java.util.List;

import com.rest.dto.Course;
import com.ts.db.HibernateTemplate;

public class CourseDAO {
      
	public Course getCourseByName(String courseName) {
		return (Course)HibernateTemplate.getObject(Course.class,courseName);
	}
	
	public Course getCourseBytutor(String offeredByLecture ) {
		return (Course)HibernateTemplate.getObject(Course.class,offeredByLecture );
	}
	
	public Course getCourseByInstitute(String offeredByInstitute) {
		return (Course)HibernateTemplate.getObject(Course.class,offeredByInstitute);
	}
	
	public Course getCourseByDuration(int duration) {
		return (Course)HibernateTemplate.getObject(Course.class,duration);
	}
	
	public List<Course> getAllCourses() {
		List<Course> courses=(List)HibernateTemplate.getObjectListByQuery("From Course");
		System.out.println("Inside All Courses ..."+courses);
		return courses;	
	}
}
