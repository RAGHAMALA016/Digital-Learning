package com.rest;

import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


import com.rest.dto.Course;

import com.rest.dto.Student;
import com.rest.dto.Tutor;
import com.ts.dao.CourseDAO;

import com.ts.dao.StudentDAO;
import com.ts.dao.TutorDAO;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
	
	@Path("Hello")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getHello() {
		return "Hello ! Welcome to REST API";
	}
	
	@Path("Hyy")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
	
	@Path("getAllStudents")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Student> getAllStudents(){
		System.out.println("Recieved in getAllStudents : " ); 
		StudentDAO studentDao = new StudentDAO();
		List<Student> stuList = studentDao.getAllStudents();	
		return stuList;
	}
	
	@Path("getAllTutors")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Tutor> getAllTutors(){
		System.out.println("Recieved in getAllTutors : " ); 
		TutorDAO tutor = new TutorDAO();
		List<Tutor> tutorList = tutor.getAllTutors();	
		return tutorList;
	}
	
	@Path("getAllCourses")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Course> getAllCourses(){
		System.out.println("Recieved in getAllCourses : " ); 
		CourseDAO course = new CourseDAO();
		List<Course> courseList = course.getAllCourses();	
		return courseList;
	}
	
	@Path("registerStudent")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	/*public void registerStudent(Student student) {
		System.out.println("Data Recieved in Register : " + student); 
		StudentDAO stu = new StudentDAO();
		stu.register(student);
		
		
	}*/
	public void registerStudent(){
		Student student = new Student();
		student.setStudentId(101);
		student.setStudentName("sushma");
		student.setCollegeName("bvrit hyderabad");
		student.setYearOfGraduation(2022);
		student.setDob(new Date(07/06/2001));
		student.setStudentMail("18wh1a0231@bvrithyderabad.edu.in");
		student.setStudentPassword("18wh1a0231");
		student.setStudentMobileNo("9381450326");
		StudentDAO stu = new StudentDAO();
		stu.register(student);
	}
	
	@Path("registerTutor")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void resisterTutor(Tutor tutor) {
		System.out.println("Data Recieved in Register : " + tutor); 
		TutorDAO tut = new TutorDAO();
		tut.register(tutor); 
	}
	
	@Path(" getCourseByName/{courseName}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Course getCourseByName(@PathParam("courseName") String courseName){
		System.out.println("Recieved in getCourseByName : " + courseName); 
		CourseDAO empDaoH = new CourseDAO();
		Course course = empDaoH.getCourseByName(courseName);	
		System.out.println(course); 
		return course;
	}
	
	/*@Path("deleteEmp/{empId}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteEmp(@PathParam("empId") int empId){
		System.out.println("Data Recieved in delete : " + empId);
		EmployeeDaoH empDao = new EmployeeDaoH();
		Employee employee = empDao.getEmployee(empId);
		empDao.deleteEmp(employee);
		
	}	
	@Path("updateEmp")
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateEmp(Employee employee){
		System.out.println("Data Recieved in update : " + employee); 
		EmployeeDaoH empDao = new EmployeeDaoH();
		empDao.updateEmp(employee);
		
	}	*/
	
	
}
