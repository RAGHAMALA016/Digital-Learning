package com.rest.dto;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
public class Course {
@Id
@GeneratedValue
private int courseId;
private String courseName;
private int noOfEnrollment;
private double price;
private String offeredByLecture;
private String offeredByInstitute;
private int duration;
private String courseInfo;

@ManyToOne
@JoinTable(name="StudentRegistrations",
joinColumns={@JoinColumn(name="courseId")},
inverseJoinColumns={@JoinColumn(name="studentId")})
private Student student;

@ManyToOne
@JoinTable(name="TutorsAssigned",
joinColumns={@JoinColumn(name="courseId")},
inverseJoinColumns={@JoinColumn(name="tutorId")})
private Tutor tutor;


public Course() {
super();
}

public Course(int courseId, String courseName, int noOfEnrollment, double price, String offeredByLecture,
		String offeredByInstitute, int duration, String courseInfo, Student student,
		Tutor tutor) {
	super();
	this.courseId = courseId;
	this.courseName = courseName;
	this.noOfEnrollment = noOfEnrollment;
	this.price = price;
	this.offeredByLecture = offeredByLecture;
	this.offeredByInstitute = offeredByInstitute;
	this.duration = duration;
	this.courseInfo = courseInfo;
	this.student = student;
	this.tutor = tutor;
}



public int getCourseId() {
	return courseId;
}

public void setCourseId(int courseId) {
	this.courseId = courseId;
}

public String getCourseName() {
	return courseName;
}

public void setCourseName(String courseName) {
	this.courseName = courseName;
}

public int getNoOfEnrollment() {
	return noOfEnrollment;
}

public void setNoOfEnrollment(int noOfEnrollment) {
	this.noOfEnrollment = noOfEnrollment;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public String getOfferedByLecture() {
	return offeredByLecture;
}

public void setOfferedByLecture(String offeredByLecture) {
	this.offeredByLecture = offeredByLecture;
}

public String getOfferedByInstitute() {
	return offeredByInstitute;
}

public void setOfferedByInstitute(String offeredByInstitute) {
	this.offeredByInstitute = offeredByInstitute;
}

public int getDuration() {
	return duration;
}

public void setDuration(int duration) {
	this.duration = duration;
}

public String getCourseInfo() {
	return courseInfo;
}

public void setCourseInfo(String courseInfo) {
	this.courseInfo = courseInfo;
}

public Student getStudent() {
	return student;
}

public void setStudent(Student student) {
	this.student = student;
}

public Tutor getTutor() {
	return tutor;
}

public void setTutor(Tutor tutor) {
	this.tutor = tutor;
}

@Override
public String toString() {
	return "Course [courseId=" + courseId + ", courseName=" + courseName + ", noOfEnrollment=" + noOfEnrollment
			+ ", price=" + price + ", offeredByLecture=" + offeredByLecture + ", offeredByInstitute="
			+ offeredByInstitute + ", duration=" + duration + ", courseInfo=" + courseInfo + ", student=" + student
			+ ", tutor=" + tutor + "]";
}



}